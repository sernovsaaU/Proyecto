package com.sr.sreclamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SreclamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SreclamoApplication.class, args);
	}

}
